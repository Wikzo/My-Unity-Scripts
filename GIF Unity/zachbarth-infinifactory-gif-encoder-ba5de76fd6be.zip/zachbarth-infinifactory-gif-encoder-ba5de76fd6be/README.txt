WHAT IS THIS?
==========================================================================================
This is the code we used for creating animated GIFs in Infinifactory. It's based
on the NGif encoder from Code Project with extensive modifications to be usable in
Unity and create highly compressed GIFs of video-like gameplay footage.

http://www.codeproject.com/Articles/11505/NGif-Animated-GIF-Encoder-for-NET

WHERE'S THE CODE?
==========================================================================================
It's in the Unity sample project, under "AnimatedGifEncoder Test\Assets\GifEncoder".

HOW'S IT LICENSED?
==========================================================================================
Use it in your projects, commercial or not, for free. Go crazy! Have fun! Read 
LICENSE.txt if you want a more concrete explanation.

I HAVE A QUESTION!
==========================================================================================
You can email me at zach@zachtronics.com, but I can't guarantee that I'll be very helpful.